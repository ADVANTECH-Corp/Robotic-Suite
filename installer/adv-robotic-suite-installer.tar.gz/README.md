# Advantech Robotic Suite

The Advantech Robotic Suite provides a consistent ROS development experience for Advantech Embedded IPC( eg. Intel x86_64, ARM NXP i.MX 8M, NVIDIA Jetson, Qualcomm ). 
The Advantech Robotic Suite installs a suitable ROS2 Distribution based on the version of Ubuntu ( eg. ROS2 Foxy for Ubuntun 20.04, ROS2 Humble for Ubuntu 22.04... ). 
Developer can easily install and set up the ROS2 environment, enableing them to quickly start developing their ROS applications.


## Installation
Install and set up the ROS2 environement.
https://docs.robotic-suite.advantech.com/

```
$ tar zxfv adv-robotic-suite-installer-<version>.tar.gz
$ sudo ./adv-robotic-suite-installer.run

Start to install the Advantech Robotic Suite

Completed
Install [Advantech Robotic Suite] completely
```

## Quick Start
Basic usage examples help to get started.
https://docs.robotic-suite.advantech.com/docs/category/tutorial/
https://docs.robotic-suite.advantech.com/docs/category/software/

## Compatible Peripheral List
There are sensors that have been verified on Advantech platforms with Advantech Robotic Suite.
https://docs.robotic-suite.advantech.com/docs/category/hardware/

## Frequently Asked Questions (FAQ)
Frequently Asked Questions on Advantech Robotic Suite
https://docs.robotic-suite.advantech.com/docs/Support/contact/

## Technology Forum
Developer can explore the technical forum for finding answers or postint your question on ROS developing.
https://forum.aim-linux.advantech.com/

## Notice: 
* The Advantech Robotic Suite supports the Ubuntu on Advantech Embedded IPC, ensuring seamless compatibility and optimized performance.